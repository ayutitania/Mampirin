<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Article;
use App\Models\Category;
use App\Support\Slug;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;
use Inertia\Inertia;
use Inertia\Response;

class ArticleController extends Controller
{
    /**
     * Show the article management table.
     */
    public function index(Request $request): Response
    {
        $search = trim((string) $request->input('search'));
        $category = $request->integer('category');
        $status = (string) $request->input('status');

        $articles = Article::query()
            ->with('category:id,name,slug')
            ->when($search !== '', fn ($query) => $query->where('title', 'like', "%{$search}%"))
            ->when($category > 0, fn ($query) => $query->where('category_id', $category))
            ->when($status === 'published', fn ($query) => $query->where('is_published', true))
            ->when($status === 'draft', fn ($query) => $query->where('is_published', false))
            ->latest('created_at')
            ->paginate(10)
            ->withQueryString();

        return Inertia::render('Admin/Articles/Index', [
            'articles' => $articles,
            'categories' => $this->categories(),
            'filters' => [
                'search' => $search,
                'category' => $category ?: '',
                'status' => $status,
            ],
        ]);
    }

    /**
     * Show the create article form.
     */
    public function create(): Response
    {
        return Inertia::render('Admin/Articles/Form', [
            'article' => null,
            'categories' => $this->categories(),
        ]);
    }

    /**
     * Store a new article.
     */
    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate($this->rules());

        $payload = $this->payload($validated, $request);
        $payload['image_url'] = $this->resolveImageUrl($request, $payload['image_url']);

        $article = Article::query()->create($payload);

        $redirect = redirect()->route('admin.articles.index')
            ->with('success', 'Artikel berhasil dibuat.');

        if ($article->is_featured && $article->is_published) {
            $featuredCount = Article::query()
                ->where('is_featured', true)
                ->where('is_published', true)
                ->count();

            if ($featuredCount > 5) {
                $redirect->with(
                    'warning',
                    'Artikel ditandai unggulan. Peringatan: sudah ada lebih dari 5 artikel unggulan, tampilan di Home akan diacak (hanya 5 yang tampil).',
                );
            }
        }

        return $redirect;
    }

    /**
     * Show the edit article form.
     */
    public function edit(Article $article): Response
    {
        return Inertia::render('Admin/Articles/Form', [
            'article' => $article->only([
                'id',
                'category_id',
                'title',
                'slug',
                'excerpt',
                'body',
                'image_url',
                'author',
                'is_featured',
                'is_published',
                'published_at',
            ]),
            'categories' => $this->categories(),
        ]);
    }

    /**
     * Update an existing article.
     */
    public function update(Request $request, Article $article): RedirectResponse
    {
        $validated = $request->validate($this->rules($article));

        $payload = $this->payload($validated, $request, $article);
        $payload['image_url'] = $this->resolveImageUrl($request, $payload['image_url'], $article);

        $article->update($payload);

        $redirect = redirect()->route('admin.articles.index')
            ->with('success', 'Artikel berhasil diperbarui.');

        if ($article->is_featured && $article->is_published) {
            $featuredCount = Article::query()
                ->where('is_featured', true)
                ->where('is_published', true)
                ->count();

            if ($featuredCount > 5) {
                $redirect->with(
                    'warning',
                    'Artikel ditandai unggulan. Peringatan: sudah ada lebih dari 5 artikel unggulan, tampilan di Home akan diacak (hanya 5 yang tampil).',
                );
            }
        }

        return $redirect;
    }

    /**
     * Toggle the published state of an article.
     */
    public function toggle(Article $article): RedirectResponse
    {
        $publishing = ! $article->is_published;

        $article->update([
            'is_published' => $publishing,
            'published_at' => $publishing
                ? ($article->published_at ?? now())
                : $article->published_at,
        ]);

        return back()->with(
            'success',
            $publishing
                ? 'Artikel berhasil dipublikasikan dan langsung tampil di situs.'
                : 'Artikel diubah menjadi draft.',
        );
    }

    /**
     * Delete an article.
     */
    public function destroy(Article $article): RedirectResponse
    {
        $article->delete();

        return redirect()->route('admin.articles.index')
            ->with('success', 'Artikel berhasil dihapus.');
    }

    /**
     * Validation rules for creating or updating an article.
     *
     * @return array<string, array<int, mixed>>
     */
    private function rules(?Article $article = null): array
    {
        return [
            'title' => ['required', 'string', 'max:255'],
            'slug' => [
                'nullable',
                'string',
                'max:255',
                Rule::unique('articles', 'slug')->ignore($article),
            ],
            'category_id' => ['required', 'integer', 'exists:categories,id'],
            'excerpt' => ['required', 'string', 'max:600'],
            'body' => ['required', 'string', 'min:50'],
            'image_url' => ['nullable', 'string', 'max:2048'],
            'article_image' => ['nullable', 'file', 'image', 'mimes:jpg,jpeg,png,webp', 'max:4096'],
            'author' => ['required', 'string', 'max:255'],
            'published_at' => ['nullable', 'date'],
            'is_featured' => ['boolean'],
            'is_published' => ['boolean'],
        ];
    }

    /**
     * Build the attributes persisted to the database.
     *
     * @param  array<string, mixed>  $validated
     * @return array<string, mixed>
     */
    private function payload(array $validated, Request $request, ?Article $article = null): array
    {
        $imageUrl = $validated['image_url'] ?? null;
        $isPublished = $request->boolean('is_published');
        $publishedAt = $validated['published_at'] ?? null;

        unset($validated['article_image'], $validated['image_url']);

        if ($isPublished && ! $publishedAt) {
            $publishedAt = $article?->published_at ?? now();
        }

        return [
            ...$validated,
            'image_url' => $imageUrl,
            'slug' => Slug::unique(
                (string) ($validated['slug'] ?: $validated['title']),
                Article::class,
                $article?->id,
            ),
            'is_featured' => $request->boolean('is_featured'),
            'is_published' => $isPublished,
            'published_at' => $publishedAt,
        ];
    }

    /**
     * Resolve the cover image for an article.
     *
     * A freshly uploaded file wins over the URL input; the old file is
     * removed when the image is replaced or the URL is emptied.
     */
    private function resolveImageUrl(Request $request, ?string $imageUrl, ?Article $article = null): ?string
    {
        if ($request->hasFile('article_image')) {
            $this->deleteStoredImage($article?->image_url);

            $path = $request->file('article_image')->store('articles', 'public');

            return '/storage/'.$path;
        }

        if (! $imageUrl && $article?->image_url) {
            $this->deleteStoredImage($article->image_url);
        }

        return $imageUrl;
    }

    /**
     * Remove a stored cover image from the public disk.
     */
    private function deleteStoredImage(?string $imageUrl): void
    {
        if ($imageUrl && str_starts_with($imageUrl, '/storage/articles/')) {
            $path = substr($imageUrl, strlen('/storage/articles/'));

            if (Storage::disk('public')->exists($path)) {
                Storage::disk('public')->delete($path);
            }
        }
    }

    /**
     * Get the category options for the form and filters.
     *
     * @return Collection<int, Category>
     */
    private function categories()
    {
        return Category::query()
            ->orderBy('sort_order')
            ->get(['id', 'name', 'slug']);
    }
}
