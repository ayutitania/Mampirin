<?php if($response): ?>
<?php echo $response->head; ?>

<?php else: ?>
<?php echo $slot; ?>

<?php endif; ?><?php /**PATH /Users/ardaswari/Documents/Coolyeah/SEMESTER 5/Desain dan Pengujian Berpusat pada Pengguna/PortalBerita/Mampirin/storage/framework/views/58f6b5ecbad88fc4da15879dbc7f6e69.blade.php ENDPATH**/ ?>