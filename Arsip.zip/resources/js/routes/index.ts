import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../wayfinder'
/**
* @see \App\Http\Controllers\HomeController::home
* @see app/Http/Controllers/HomeController.php:15
* @route '/'
*/
export const home = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: home.url(options),
    method: 'get',
})

home.definition = {
    methods: ["get","head"],
    url: '/',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HomeController::home
* @see app/Http/Controllers/HomeController.php:15
* @route '/'
*/
home.url = (options?: RouteQueryOptions) => {
    return home.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HomeController::home
* @see app/Http/Controllers/HomeController.php:15
* @route '/'
*/
home.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: home.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HomeController::home
* @see app/Http/Controllers/HomeController.php:15
* @route '/'
*/
home.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: home.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\HomeController::home
* @see app/Http/Controllers/HomeController.php:15
* @route '/'
*/
const homeForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: home.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HomeController::home
* @see app/Http/Controllers/HomeController.php:15
* @route '/'
*/
homeForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: home.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HomeController::home
* @see app/Http/Controllers/HomeController.php:15
* @route '/'
*/
homeForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: home.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

home.form = homeForm

/**
* @see \App\Http\Controllers\ArticleController::search
* @see app/Http/Controllers/ArticleController.php:84
* @route '/search'
*/
export const search = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: search.url(options),
    method: 'get',
})

search.definition = {
    methods: ["get","head"],
    url: '/search',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ArticleController::search
* @see app/Http/Controllers/ArticleController.php:84
* @route '/search'
*/
search.url = (options?: RouteQueryOptions) => {
    return search.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ArticleController::search
* @see app/Http/Controllers/ArticleController.php:84
* @route '/search'
*/
search.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: search.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ArticleController::search
* @see app/Http/Controllers/ArticleController.php:84
* @route '/search'
*/
search.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: search.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ArticleController::search
* @see app/Http/Controllers/ArticleController.php:84
* @route '/search'
*/
const searchForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: search.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ArticleController::search
* @see app/Http/Controllers/ArticleController.php:84
* @route '/search'
*/
searchForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: search.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ArticleController::search
* @see app/Http/Controllers/ArticleController.php:84
* @route '/search'
*/
searchForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: search.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

search.form = searchForm

/**
* @see \App\Http\Controllers\AboutController::about
* @see app/Http/Controllers/AboutController.php:14
* @route '/about'
*/
export const about = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: about.url(options),
    method: 'get',
})

about.definition = {
    methods: ["get","head"],
    url: '/about',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AboutController::about
* @see app/Http/Controllers/AboutController.php:14
* @route '/about'
*/
about.url = (options?: RouteQueryOptions) => {
    return about.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AboutController::about
* @see app/Http/Controllers/AboutController.php:14
* @route '/about'
*/
about.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: about.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AboutController::about
* @see app/Http/Controllers/AboutController.php:14
* @route '/about'
*/
about.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: about.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\AboutController::about
* @see app/Http/Controllers/AboutController.php:14
* @route '/about'
*/
const aboutForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: about.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AboutController::about
* @see app/Http/Controllers/AboutController.php:14
* @route '/about'
*/
aboutForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: about.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AboutController::about
* @see app/Http/Controllers/AboutController.php:14
* @route '/about'
*/
aboutForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: about.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

about.form = aboutForm

/**
* @see \App\Http\Controllers\AdsController::ads
* @see app/Http/Controllers/AdsController.php:14
* @route '/ads'
*/
export const ads = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ads.url(options),
    method: 'get',
})

ads.definition = {
    methods: ["get","head"],
    url: '/ads',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdsController::ads
* @see app/Http/Controllers/AdsController.php:14
* @route '/ads'
*/
ads.url = (options?: RouteQueryOptions) => {
    return ads.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdsController::ads
* @see app/Http/Controllers/AdsController.php:14
* @route '/ads'
*/
ads.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ads.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdsController::ads
* @see app/Http/Controllers/AdsController.php:14
* @route '/ads'
*/
ads.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: ads.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\AdsController::ads
* @see app/Http/Controllers/AdsController.php:14
* @route '/ads'
*/
const adsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: ads.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdsController::ads
* @see app/Http/Controllers/AdsController.php:14
* @route '/ads'
*/
adsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: ads.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdsController::ads
* @see app/Http/Controllers/AdsController.php:14
* @route '/ads'
*/
adsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: ads.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

ads.form = adsForm

/**
* @see \App\Http\Controllers\FaqController::faq
* @see app/Http/Controllers/FaqController.php:13
* @route '/faq'
*/
export const faq = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: faq.url(options),
    method: 'get',
})

faq.definition = {
    methods: ["get","head"],
    url: '/faq',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FaqController::faq
* @see app/Http/Controllers/FaqController.php:13
* @route '/faq'
*/
faq.url = (options?: RouteQueryOptions) => {
    return faq.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FaqController::faq
* @see app/Http/Controllers/FaqController.php:13
* @route '/faq'
*/
faq.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: faq.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FaqController::faq
* @see app/Http/Controllers/FaqController.php:13
* @route '/faq'
*/
faq.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: faq.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FaqController::faq
* @see app/Http/Controllers/FaqController.php:13
* @route '/faq'
*/
const faqForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: faq.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FaqController::faq
* @see app/Http/Controllers/FaqController.php:13
* @route '/faq'
*/
faqForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: faq.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FaqController::faq
* @see app/Http/Controllers/FaqController.php:13
* @route '/faq'
*/
faqForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: faq.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

faq.form = faqForm

/**
* @see routes/web.php:57
* @route '/write-us'
*/
export const writeUs = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: writeUs.url(options),
    method: 'get',
})

writeUs.definition = {
    methods: ["get","head"],
    url: '/write-us',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:57
* @route '/write-us'
*/
writeUs.url = (options?: RouteQueryOptions) => {
    return writeUs.definition.url + queryParams(options)
}

/**
* @see routes/web.php:57
* @route '/write-us'
*/
writeUs.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: writeUs.url(options),
    method: 'get',
})

/**
* @see routes/web.php:57
* @route '/write-us'
*/
writeUs.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: writeUs.url(options),
    method: 'head',
})

/**
* @see routes/web.php:57
* @route '/write-us'
*/
const writeUsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: writeUs.url(options),
    method: 'get',
})

/**
* @see routes/web.php:57
* @route '/write-us'
*/
writeUsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: writeUs.url(options),
    method: 'get',
})

/**
* @see routes/web.php:57
* @route '/write-us'
*/
writeUsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: writeUs.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

writeUs.form = writeUsForm
