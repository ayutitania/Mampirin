import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\ArticleController::index
* @see app/Http/Controllers/ArticleController.php:17
* @route '/article'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/article',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ArticleController::index
* @see app/Http/Controllers/ArticleController.php:17
* @route '/article'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ArticleController::index
* @see app/Http/Controllers/ArticleController.php:17
* @route '/article'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ArticleController::index
* @see app/Http/Controllers/ArticleController.php:17
* @route '/article'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ArticleController::index
* @see app/Http/Controllers/ArticleController.php:17
* @route '/article'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ArticleController::index
* @see app/Http/Controllers/ArticleController.php:17
* @route '/article'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ArticleController::index
* @see app/Http/Controllers/ArticleController.php:17
* @route '/article'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\ArticleController::entertainment
* @see app/Http/Controllers/ArticleController.php:25
* @route '/article/entertainment'
*/
export const entertainment = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: entertainment.url(options),
    method: 'get',
})

entertainment.definition = {
    methods: ["get","head"],
    url: '/article/entertainment',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ArticleController::entertainment
* @see app/Http/Controllers/ArticleController.php:25
* @route '/article/entertainment'
*/
entertainment.url = (options?: RouteQueryOptions) => {
    return entertainment.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ArticleController::entertainment
* @see app/Http/Controllers/ArticleController.php:25
* @route '/article/entertainment'
*/
entertainment.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: entertainment.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ArticleController::entertainment
* @see app/Http/Controllers/ArticleController.php:25
* @route '/article/entertainment'
*/
entertainment.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: entertainment.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ArticleController::entertainment
* @see app/Http/Controllers/ArticleController.php:25
* @route '/article/entertainment'
*/
const entertainmentForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: entertainment.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ArticleController::entertainment
* @see app/Http/Controllers/ArticleController.php:25
* @route '/article/entertainment'
*/
entertainmentForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: entertainment.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ArticleController::entertainment
* @see app/Http/Controllers/ArticleController.php:25
* @route '/article/entertainment'
*/
entertainmentForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: entertainment.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

entertainment.form = entertainmentForm

/**
* @see \App\Http\Controllers\ArticleController::history
* @see app/Http/Controllers/ArticleController.php:33
* @route '/article/history'
*/
export const history = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: history.url(options),
    method: 'get',
})

history.definition = {
    methods: ["get","head"],
    url: '/article/history',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ArticleController::history
* @see app/Http/Controllers/ArticleController.php:33
* @route '/article/history'
*/
history.url = (options?: RouteQueryOptions) => {
    return history.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ArticleController::history
* @see app/Http/Controllers/ArticleController.php:33
* @route '/article/history'
*/
history.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: history.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ArticleController::history
* @see app/Http/Controllers/ArticleController.php:33
* @route '/article/history'
*/
history.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: history.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ArticleController::history
* @see app/Http/Controllers/ArticleController.php:33
* @route '/article/history'
*/
const historyForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: history.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ArticleController::history
* @see app/Http/Controllers/ArticleController.php:33
* @route '/article/history'
*/
historyForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: history.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ArticleController::history
* @see app/Http/Controllers/ArticleController.php:33
* @route '/article/history'
*/
historyForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: history.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

history.form = historyForm

/**
* @see \App\Http\Controllers\ArticleController::lifestyle
* @see app/Http/Controllers/ArticleController.php:41
* @route '/article/lifestyle'
*/
export const lifestyle = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: lifestyle.url(options),
    method: 'get',
})

lifestyle.definition = {
    methods: ["get","head"],
    url: '/article/lifestyle',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ArticleController::lifestyle
* @see app/Http/Controllers/ArticleController.php:41
* @route '/article/lifestyle'
*/
lifestyle.url = (options?: RouteQueryOptions) => {
    return lifestyle.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ArticleController::lifestyle
* @see app/Http/Controllers/ArticleController.php:41
* @route '/article/lifestyle'
*/
lifestyle.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: lifestyle.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ArticleController::lifestyle
* @see app/Http/Controllers/ArticleController.php:41
* @route '/article/lifestyle'
*/
lifestyle.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: lifestyle.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ArticleController::lifestyle
* @see app/Http/Controllers/ArticleController.php:41
* @route '/article/lifestyle'
*/
const lifestyleForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: lifestyle.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ArticleController::lifestyle
* @see app/Http/Controllers/ArticleController.php:41
* @route '/article/lifestyle'
*/
lifestyleForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: lifestyle.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ArticleController::lifestyle
* @see app/Http/Controllers/ArticleController.php:41
* @route '/article/lifestyle'
*/
lifestyleForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: lifestyle.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

lifestyle.form = lifestyleForm

/**
* @see \App\Http\Controllers\ArticleController::category
* @see app/Http/Controllers/ArticleController.php:49
* @route '/article/category/{slug}'
*/
export const category = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: category.url(args, options),
    method: 'get',
})

category.definition = {
    methods: ["get","head"],
    url: '/article/category/{slug}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ArticleController::category
* @see app/Http/Controllers/ArticleController.php:49
* @route '/article/category/{slug}'
*/
category.url = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { slug: args }
    }

    if (Array.isArray(args)) {
        args = {
            slug: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        slug: args.slug,
    }

    return category.definition.url
            .replace('{slug}', parsedArgs.slug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ArticleController::category
* @see app/Http/Controllers/ArticleController.php:49
* @route '/article/category/{slug}'
*/
category.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: category.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ArticleController::category
* @see app/Http/Controllers/ArticleController.php:49
* @route '/article/category/{slug}'
*/
category.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: category.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ArticleController::category
* @see app/Http/Controllers/ArticleController.php:49
* @route '/article/category/{slug}'
*/
const categoryForm = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: category.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ArticleController::category
* @see app/Http/Controllers/ArticleController.php:49
* @route '/article/category/{slug}'
*/
categoryForm.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: category.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ArticleController::category
* @see app/Http/Controllers/ArticleController.php:49
* @route '/article/category/{slug}'
*/
categoryForm.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: category.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

category.form = categoryForm

/**
* @see \App\Http\Controllers\ArticleController::show
* @see app/Http/Controllers/ArticleController.php:111
* @route '/article/{slug}'
*/
export const show = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/article/{slug}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ArticleController::show
* @see app/Http/Controllers/ArticleController.php:111
* @route '/article/{slug}'
*/
show.url = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { slug: args }
    }

    if (Array.isArray(args)) {
        args = {
            slug: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        slug: args.slug,
    }

    return show.definition.url
            .replace('{slug}', parsedArgs.slug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ArticleController::show
* @see app/Http/Controllers/ArticleController.php:111
* @route '/article/{slug}'
*/
show.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ArticleController::show
* @see app/Http/Controllers/ArticleController.php:111
* @route '/article/{slug}'
*/
show.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ArticleController::show
* @see app/Http/Controllers/ArticleController.php:111
* @route '/article/{slug}'
*/
const showForm = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ArticleController::show
* @see app/Http/Controllers/ArticleController.php:111
* @route '/article/{slug}'
*/
showForm.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ArticleController::show
* @see app/Http/Controllers/ArticleController.php:111
* @route '/article/{slug}'
*/
showForm.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

const article = {
    index: Object.assign(index, index),
    entertainment: Object.assign(entertainment, entertainment),
    history: Object.assign(history, history),
    lifestyle: Object.assign(lifestyle, lifestyle),
    category: Object.assign(category, category),
    show: Object.assign(show, show),
}

export default article