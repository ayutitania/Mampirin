import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
import order7d625c from './order'
import payment44796b from './payment'
/**
* @see \App\Http\Controllers\AdOrderController::order
* @see app/Http/Controllers/AdOrderController.php:118
* @route '/blade/ads/order'
*/
export const order = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: order.url(options),
    method: 'get',
})

order.definition = {
    methods: ["get","head"],
    url: '/blade/ads/order',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdOrderController::order
* @see app/Http/Controllers/AdOrderController.php:118
* @route '/blade/ads/order'
*/
order.url = (options?: RouteQueryOptions) => {
    return order.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdOrderController::order
* @see app/Http/Controllers/AdOrderController.php:118
* @route '/blade/ads/order'
*/
order.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: order.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdOrderController::order
* @see app/Http/Controllers/AdOrderController.php:118
* @route '/blade/ads/order'
*/
order.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: order.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\AdOrderController::order
* @see app/Http/Controllers/AdOrderController.php:118
* @route '/blade/ads/order'
*/
const orderForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: order.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdOrderController::order
* @see app/Http/Controllers/AdOrderController.php:118
* @route '/blade/ads/order'
*/
orderForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: order.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdOrderController::order
* @see app/Http/Controllers/AdOrderController.php:118
* @route '/blade/ads/order'
*/
orderForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: order.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

order.form = orderForm

/**
* @see \App\Http\Controllers\AdOrderController::payment
* @see app/Http/Controllers/AdOrderController.php:176
* @route '/blade/ads/payment/{order}'
*/
export const payment = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: payment.url(args, options),
    method: 'get',
})

payment.definition = {
    methods: ["get","head"],
    url: '/blade/ads/payment/{order}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdOrderController::payment
* @see app/Http/Controllers/AdOrderController.php:176
* @route '/blade/ads/payment/{order}'
*/
payment.url = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order: args }
    }

    if (Array.isArray(args)) {
        args = {
            order: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        order: args.order,
    }

    return payment.definition.url
            .replace('{order}', parsedArgs.order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdOrderController::payment
* @see app/Http/Controllers/AdOrderController.php:176
* @route '/blade/ads/payment/{order}'
*/
payment.get = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: payment.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdOrderController::payment
* @see app/Http/Controllers/AdOrderController.php:176
* @route '/blade/ads/payment/{order}'
*/
payment.head = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: payment.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\AdOrderController::payment
* @see app/Http/Controllers/AdOrderController.php:176
* @route '/blade/ads/payment/{order}'
*/
const paymentForm = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: payment.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdOrderController::payment
* @see app/Http/Controllers/AdOrderController.php:176
* @route '/blade/ads/payment/{order}'
*/
paymentForm.get = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: payment.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdOrderController::payment
* @see app/Http/Controllers/AdOrderController.php:176
* @route '/blade/ads/payment/{order}'
*/
paymentForm.head = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: payment.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

payment.form = paymentForm

const ads = {
    order: Object.assign(order, order7d625c),
    payment: Object.assign(payment, payment44796b),
}

export default ads