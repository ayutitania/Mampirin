import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AdOrderController::simulate
* @see app/Http/Controllers/AdOrderController.php:189
* @route '/blade/ads/payment/{order}/simulate'
*/
export const simulate = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: simulate.url(args, options),
    method: 'post',
})

simulate.definition = {
    methods: ["post"],
    url: '/blade/ads/payment/{order}/simulate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdOrderController::simulate
* @see app/Http/Controllers/AdOrderController.php:189
* @route '/blade/ads/payment/{order}/simulate'
*/
simulate.url = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order: args }
    }

    if (Array.isArray(args)) {
        args = {
            order: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        order: args.order,
    }

    return simulate.definition.url
            .replace('{order}', parsedArgs.order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdOrderController::simulate
* @see app/Http/Controllers/AdOrderController.php:189
* @route '/blade/ads/payment/{order}/simulate'
*/
simulate.post = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: simulate.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AdOrderController::simulate
* @see app/Http/Controllers/AdOrderController.php:189
* @route '/blade/ads/payment/{order}/simulate'
*/
const simulateForm = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: simulate.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AdOrderController::simulate
* @see app/Http/Controllers/AdOrderController.php:189
* @route '/blade/ads/payment/{order}/simulate'
*/
simulateForm.post = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: simulate.url(args, options),
    method: 'post',
})

simulate.form = simulateForm

const payment = {
    simulate: Object.assign(simulate, simulate),
}

export default payment