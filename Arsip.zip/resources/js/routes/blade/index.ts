import ads from './ads'

const blade = {
    ads: Object.assign(ads, ads),
}

export default blade