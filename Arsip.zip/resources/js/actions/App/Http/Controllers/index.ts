import HomeController from './HomeController'
import ArticleController from './ArticleController'
import AboutController from './AboutController'
import AdsController from './AdsController'
import FaqController from './FaqController'
import PartnershipController from './PartnershipController'
import AdOrderController from './AdOrderController'
import ArticleSubmissionController from './ArticleSubmissionController'
import Admin from './Admin'

const Controllers = {
    HomeController: Object.assign(HomeController, HomeController),
    ArticleController: Object.assign(ArticleController, ArticleController),
    AboutController: Object.assign(AboutController, AboutController),
    AdsController: Object.assign(AdsController, AdsController),
    FaqController: Object.assign(FaqController, FaqController),
    PartnershipController: Object.assign(PartnershipController, PartnershipController),
    AdOrderController: Object.assign(AdOrderController, AdOrderController),
    ArticleSubmissionController: Object.assign(ArticleSubmissionController, ArticleSubmissionController),
    Admin: Object.assign(Admin, Admin),
}

export default Controllers