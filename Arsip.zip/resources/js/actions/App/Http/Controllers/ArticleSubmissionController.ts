import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ArticleSubmissionController::store
* @see app/Http/Controllers/ArticleSubmissionController.php:14
* @route '/write-us'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/write-us',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ArticleSubmissionController::store
* @see app/Http/Controllers/ArticleSubmissionController.php:14
* @route '/write-us'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ArticleSubmissionController::store
* @see app/Http/Controllers/ArticleSubmissionController.php:14
* @route '/write-us'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ArticleSubmissionController::store
* @see app/Http/Controllers/ArticleSubmissionController.php:14
* @route '/write-us'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ArticleSubmissionController::store
* @see app/Http/Controllers/ArticleSubmissionController.php:14
* @route '/write-us'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

const ArticleSubmissionController = { store }

export default ArticleSubmissionController