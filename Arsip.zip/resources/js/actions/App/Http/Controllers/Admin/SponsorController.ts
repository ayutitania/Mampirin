import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\SponsorController::index
* @see app/Http/Controllers/Admin/SponsorController.php:19
* @route '/admin/sponsors'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/sponsors',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\SponsorController::index
* @see app/Http/Controllers/Admin/SponsorController.php:19
* @route '/admin/sponsors'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SponsorController::index
* @see app/Http/Controllers/Admin/SponsorController.php:19
* @route '/admin/sponsors'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\SponsorController::index
* @see app/Http/Controllers/Admin/SponsorController.php:19
* @route '/admin/sponsors'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\SponsorController::index
* @see app/Http/Controllers/Admin/SponsorController.php:19
* @route '/admin/sponsors'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\SponsorController::index
* @see app/Http/Controllers/Admin/SponsorController.php:19
* @route '/admin/sponsors'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\SponsorController::index
* @see app/Http/Controllers/Admin/SponsorController.php:19
* @route '/admin/sponsors'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Admin\SponsorController::approve
* @see app/Http/Controllers/Admin/SponsorController.php:83
* @route '/admin/sponsors/{inquiry}/approve'
*/
export const approve = (args: { inquiry: number | { id: number } } | [inquiry: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

approve.definition = {
    methods: ["post"],
    url: '/admin/sponsors/{inquiry}/approve',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\SponsorController::approve
* @see app/Http/Controllers/Admin/SponsorController.php:83
* @route '/admin/sponsors/{inquiry}/approve'
*/
approve.url = (args: { inquiry: number | { id: number } } | [inquiry: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { inquiry: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { inquiry: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            inquiry: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        inquiry: typeof args.inquiry === 'object'
        ? args.inquiry.id
        : args.inquiry,
    }

    return approve.definition.url
            .replace('{inquiry}', parsedArgs.inquiry.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SponsorController::approve
* @see app/Http/Controllers/Admin/SponsorController.php:83
* @route '/admin/sponsors/{inquiry}/approve'
*/
approve.post = (args: { inquiry: number | { id: number } } | [inquiry: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\SponsorController::approve
* @see app/Http/Controllers/Admin/SponsorController.php:83
* @route '/admin/sponsors/{inquiry}/approve'
*/
const approveForm = (args: { inquiry: number | { id: number } } | [inquiry: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: approve.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\SponsorController::approve
* @see app/Http/Controllers/Admin/SponsorController.php:83
* @route '/admin/sponsors/{inquiry}/approve'
*/
approveForm.post = (args: { inquiry: number | { id: number } } | [inquiry: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: approve.url(args, options),
    method: 'post',
})

approve.form = approveForm

/**
* @see \App\Http\Controllers\Admin\SponsorController::updateStatus
* @see app/Http/Controllers/Admin/SponsorController.php:63
* @route '/admin/sponsors/{inquiry}/status'
*/
export const updateStatus = (args: { inquiry: number | { id: number } } | [inquiry: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateStatus.url(args, options),
    method: 'patch',
})

updateStatus.definition = {
    methods: ["patch"],
    url: '/admin/sponsors/{inquiry}/status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Admin\SponsorController::updateStatus
* @see app/Http/Controllers/Admin/SponsorController.php:63
* @route '/admin/sponsors/{inquiry}/status'
*/
updateStatus.url = (args: { inquiry: number | { id: number } } | [inquiry: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { inquiry: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { inquiry: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            inquiry: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        inquiry: typeof args.inquiry === 'object'
        ? args.inquiry.id
        : args.inquiry,
    }

    return updateStatus.definition.url
            .replace('{inquiry}', parsedArgs.inquiry.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SponsorController::updateStatus
* @see app/Http/Controllers/Admin/SponsorController.php:63
* @route '/admin/sponsors/{inquiry}/status'
*/
updateStatus.patch = (args: { inquiry: number | { id: number } } | [inquiry: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateStatus.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\Admin\SponsorController::updateStatus
* @see app/Http/Controllers/Admin/SponsorController.php:63
* @route '/admin/sponsors/{inquiry}/status'
*/
const updateStatusForm = (args: { inquiry: number | { id: number } } | [inquiry: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateStatus.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\SponsorController::updateStatus
* @see app/Http/Controllers/Admin/SponsorController.php:63
* @route '/admin/sponsors/{inquiry}/status'
*/
updateStatusForm.patch = (args: { inquiry: number | { id: number } } | [inquiry: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateStatus.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

updateStatus.form = updateStatusForm

/**
* @see \App\Http\Controllers\Admin\SponsorController::destroy
* @see app/Http/Controllers/Admin/SponsorController.php:136
* @route '/admin/sponsors/{inquiry}'
*/
export const destroy = (args: { inquiry: number | { id: number } } | [inquiry: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/sponsors/{inquiry}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\SponsorController::destroy
* @see app/Http/Controllers/Admin/SponsorController.php:136
* @route '/admin/sponsors/{inquiry}'
*/
destroy.url = (args: { inquiry: number | { id: number } } | [inquiry: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { inquiry: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { inquiry: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            inquiry: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        inquiry: typeof args.inquiry === 'object'
        ? args.inquiry.id
        : args.inquiry,
    }

    return destroy.definition.url
            .replace('{inquiry}', parsedArgs.inquiry.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SponsorController::destroy
* @see app/Http/Controllers/Admin/SponsorController.php:136
* @route '/admin/sponsors/{inquiry}'
*/
destroy.delete = (args: { inquiry: number | { id: number } } | [inquiry: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Admin\SponsorController::destroy
* @see app/Http/Controllers/Admin/SponsorController.php:136
* @route '/admin/sponsors/{inquiry}'
*/
const destroyForm = (args: { inquiry: number | { id: number } } | [inquiry: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\SponsorController::destroy
* @see app/Http/Controllers/Admin/SponsorController.php:136
* @route '/admin/sponsors/{inquiry}'
*/
destroyForm.delete = (args: { inquiry: number | { id: number } } | [inquiry: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const SponsorController = { index, approve, updateStatus, destroy }

export default SponsorController