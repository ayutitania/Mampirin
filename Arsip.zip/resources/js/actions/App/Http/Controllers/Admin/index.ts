import AuthController from './AuthController'
import DashboardController from './DashboardController'
import ArticleController from './ArticleController'
import CategoryController from './CategoryController'
import SubmissionController from './SubmissionController'
import AdController from './AdController'
import SponsorController from './SponsorController'

const Admin = {
    AuthController: Object.assign(AuthController, AuthController),
    DashboardController: Object.assign(DashboardController, DashboardController),
    ArticleController: Object.assign(ArticleController, ArticleController),
    CategoryController: Object.assign(CategoryController, CategoryController),
    SubmissionController: Object.assign(SubmissionController, SubmissionController),
    AdController: Object.assign(AdController, AdController),
    SponsorController: Object.assign(SponsorController, SponsorController),
}

export default Admin