import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AdController::toggle
* @see app/Http/Controllers/Admin/AdController.php:108
* @route '/admin/ads/{ad}/toggle'
*/
export const toggle = (args: { ad: number | { id: number } } | [ad: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: toggle.url(args, options),
    method: 'patch',
})

toggle.definition = {
    methods: ["patch"],
    url: '/admin/ads/{ad}/toggle',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Admin\AdController::toggle
* @see app/Http/Controllers/Admin/AdController.php:108
* @route '/admin/ads/{ad}/toggle'
*/
toggle.url = (args: { ad: number | { id: number } } | [ad: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ad: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { ad: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            ad: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        ad: typeof args.ad === 'object'
        ? args.ad.id
        : args.ad,
    }

    return toggle.definition.url
            .replace('{ad}', parsedArgs.ad.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdController::toggle
* @see app/Http/Controllers/Admin/AdController.php:108
* @route '/admin/ads/{ad}/toggle'
*/
toggle.patch = (args: { ad: number | { id: number } } | [ad: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: toggle.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\Admin\AdController::toggle
* @see app/Http/Controllers/Admin/AdController.php:108
* @route '/admin/ads/{ad}/toggle'
*/
const toggleForm = (args: { ad: number | { id: number } } | [ad: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: toggle.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AdController::toggle
* @see app/Http/Controllers/Admin/AdController.php:108
* @route '/admin/ads/{ad}/toggle'
*/
toggleForm.patch = (args: { ad: number | { id: number } } | [ad: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: toggle.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

toggle.form = toggleForm

/**
* @see \App\Http\Controllers\Admin\AdController::index
* @see app/Http/Controllers/Admin/AdController.php:19
* @route '/admin/ads'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/ads',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AdController::index
* @see app/Http/Controllers/Admin/AdController.php:19
* @route '/admin/ads'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdController::index
* @see app/Http/Controllers/Admin/AdController.php:19
* @route '/admin/ads'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AdController::index
* @see app/Http/Controllers/Admin/AdController.php:19
* @route '/admin/ads'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\AdController::index
* @see app/Http/Controllers/Admin/AdController.php:19
* @route '/admin/ads'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AdController::index
* @see app/Http/Controllers/Admin/AdController.php:19
* @route '/admin/ads'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AdController::index
* @see app/Http/Controllers/Admin/AdController.php:19
* @route '/admin/ads'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Admin\AdController::create
* @see app/Http/Controllers/Admin/AdController.php:50
* @route '/admin/ads/create'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/ads/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AdController::create
* @see app/Http/Controllers/Admin/AdController.php:50
* @route '/admin/ads/create'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdController::create
* @see app/Http/Controllers/Admin/AdController.php:50
* @route '/admin/ads/create'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AdController::create
* @see app/Http/Controllers/Admin/AdController.php:50
* @route '/admin/ads/create'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\AdController::create
* @see app/Http/Controllers/Admin/AdController.php:50
* @route '/admin/ads/create'
*/
const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AdController::create
* @see app/Http/Controllers/Admin/AdController.php:50
* @route '/admin/ads/create'
*/
createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AdController::create
* @see app/Http/Controllers/Admin/AdController.php:50
* @route '/admin/ads/create'
*/
createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

create.form = createForm

/**
* @see \App\Http\Controllers\Admin\AdController::store
* @see app/Http/Controllers/Admin/AdController.php:61
* @route '/admin/ads'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/ads',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AdController::store
* @see app/Http/Controllers/Admin/AdController.php:61
* @route '/admin/ads'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdController::store
* @see app/Http/Controllers/Admin/AdController.php:61
* @route '/admin/ads'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AdController::store
* @see app/Http/Controllers/Admin/AdController.php:61
* @route '/admin/ads'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AdController::store
* @see app/Http/Controllers/Admin/AdController.php:61
* @route '/admin/ads'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Admin\AdController::edit
* @see app/Http/Controllers/Admin/AdController.php:74
* @route '/admin/ads/{ad}/edit'
*/
export const edit = (args: { ad: number | { id: number } } | [ad: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/ads/{ad}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AdController::edit
* @see app/Http/Controllers/Admin/AdController.php:74
* @route '/admin/ads/{ad}/edit'
*/
edit.url = (args: { ad: number | { id: number } } | [ad: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ad: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { ad: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            ad: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        ad: typeof args.ad === 'object'
        ? args.ad.id
        : args.ad,
    }

    return edit.definition.url
            .replace('{ad}', parsedArgs.ad.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdController::edit
* @see app/Http/Controllers/Admin/AdController.php:74
* @route '/admin/ads/{ad}/edit'
*/
edit.get = (args: { ad: number | { id: number } } | [ad: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AdController::edit
* @see app/Http/Controllers/Admin/AdController.php:74
* @route '/admin/ads/{ad}/edit'
*/
edit.head = (args: { ad: number | { id: number } } | [ad: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\AdController::edit
* @see app/Http/Controllers/Admin/AdController.php:74
* @route '/admin/ads/{ad}/edit'
*/
const editForm = (args: { ad: number | { id: number } } | [ad: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AdController::edit
* @see app/Http/Controllers/Admin/AdController.php:74
* @route '/admin/ads/{ad}/edit'
*/
editForm.get = (args: { ad: number | { id: number } } | [ad: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AdController::edit
* @see app/Http/Controllers/Admin/AdController.php:74
* @route '/admin/ads/{ad}/edit'
*/
editForm.head = (args: { ad: number | { id: number } } | [ad: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

/**
* @see \App\Http\Controllers\Admin\AdController::update
* @see app/Http/Controllers/Admin/AdController.php:95
* @route '/admin/ads/{ad}'
*/
export const update = (args: { ad: number | { id: number } } | [ad: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/admin/ads/{ad}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Admin\AdController::update
* @see app/Http/Controllers/Admin/AdController.php:95
* @route '/admin/ads/{ad}'
*/
update.url = (args: { ad: number | { id: number } } | [ad: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ad: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { ad: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            ad: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        ad: typeof args.ad === 'object'
        ? args.ad.id
        : args.ad,
    }

    return update.definition.url
            .replace('{ad}', parsedArgs.ad.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdController::update
* @see app/Http/Controllers/Admin/AdController.php:95
* @route '/admin/ads/{ad}'
*/
update.put = (args: { ad: number | { id: number } } | [ad: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Admin\AdController::update
* @see app/Http/Controllers/Admin/AdController.php:95
* @route '/admin/ads/{ad}'
*/
update.patch = (args: { ad: number | { id: number } } | [ad: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\Admin\AdController::update
* @see app/Http/Controllers/Admin/AdController.php:95
* @route '/admin/ads/{ad}'
*/
const updateForm = (args: { ad: number | { id: number } } | [ad: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AdController::update
* @see app/Http/Controllers/Admin/AdController.php:95
* @route '/admin/ads/{ad}'
*/
updateForm.put = (args: { ad: number | { id: number } } | [ad: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AdController::update
* @see app/Http/Controllers/Admin/AdController.php:95
* @route '/admin/ads/{ad}'
*/
updateForm.patch = (args: { ad: number | { id: number } } | [ad: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Admin\AdController::destroy
* @see app/Http/Controllers/Admin/AdController.php:123
* @route '/admin/ads/{ad}'
*/
export const destroy = (args: { ad: number | { id: number } } | [ad: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/ads/{ad}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\AdController::destroy
* @see app/Http/Controllers/Admin/AdController.php:123
* @route '/admin/ads/{ad}'
*/
destroy.url = (args: { ad: number | { id: number } } | [ad: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ad: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { ad: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            ad: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        ad: typeof args.ad === 'object'
        ? args.ad.id
        : args.ad,
    }

    return destroy.definition.url
            .replace('{ad}', parsedArgs.ad.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdController::destroy
* @see app/Http/Controllers/Admin/AdController.php:123
* @route '/admin/ads/{ad}'
*/
destroy.delete = (args: { ad: number | { id: number } } | [ad: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Admin\AdController::destroy
* @see app/Http/Controllers/Admin/AdController.php:123
* @route '/admin/ads/{ad}'
*/
const destroyForm = (args: { ad: number | { id: number } } | [ad: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AdController::destroy
* @see app/Http/Controllers/Admin/AdController.php:123
* @route '/admin/ads/{ad}'
*/
destroyForm.delete = (args: { ad: number | { id: number } } | [ad: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const AdController = { toggle, index, create, store, edit, update, destroy }

export default AdController