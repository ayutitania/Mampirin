import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\PartnershipController::index
* @see app/Http/Controllers/PartnershipController.php:17
* @route '/partnership'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/partnership',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PartnershipController::index
* @see app/Http/Controllers/PartnershipController.php:17
* @route '/partnership'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PartnershipController::index
* @see app/Http/Controllers/PartnershipController.php:17
* @route '/partnership'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PartnershipController::index
* @see app/Http/Controllers/PartnershipController.php:17
* @route '/partnership'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PartnershipController::index
* @see app/Http/Controllers/PartnershipController.php:17
* @route '/partnership'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PartnershipController::index
* @see app/Http/Controllers/PartnershipController.php:17
* @route '/partnership'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PartnershipController::index
* @see app/Http/Controllers/PartnershipController.php:17
* @route '/partnership'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\PartnershipController::store
* @see app/Http/Controllers/PartnershipController.php:51
* @route '/partnership'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/partnership',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PartnershipController::store
* @see app/Http/Controllers/PartnershipController.php:51
* @route '/partnership'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PartnershipController::store
* @see app/Http/Controllers/PartnershipController.php:51
* @route '/partnership'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PartnershipController::store
* @see app/Http/Controllers/PartnershipController.php:51
* @route '/partnership'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PartnershipController::store
* @see app/Http/Controllers/PartnershipController.php:51
* @route '/partnership'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

const PartnershipController = { index, store }

export default PartnershipController