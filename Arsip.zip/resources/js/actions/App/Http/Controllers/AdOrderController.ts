import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AdOrderController::create
* @see app/Http/Controllers/AdOrderController.php:15
* @route '/ads/order'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/ads/order',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdOrderController::create
* @see app/Http/Controllers/AdOrderController.php:15
* @route '/ads/order'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdOrderController::create
* @see app/Http/Controllers/AdOrderController.php:15
* @route '/ads/order'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdOrderController::create
* @see app/Http/Controllers/AdOrderController.php:15
* @route '/ads/order'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\AdOrderController::create
* @see app/Http/Controllers/AdOrderController.php:15
* @route '/ads/order'
*/
const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdOrderController::create
* @see app/Http/Controllers/AdOrderController.php:15
* @route '/ads/order'
*/
createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdOrderController::create
* @see app/Http/Controllers/AdOrderController.php:15
* @route '/ads/order'
*/
createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

create.form = createForm

/**
* @see \App\Http\Controllers\AdOrderController::store
* @see app/Http/Controllers/AdOrderController.php:33
* @route '/ads/order'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/ads/order',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdOrderController::store
* @see app/Http/Controllers/AdOrderController.php:33
* @route '/ads/order'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdOrderController::store
* @see app/Http/Controllers/AdOrderController.php:33
* @route '/ads/order'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AdOrderController::store
* @see app/Http/Controllers/AdOrderController.php:33
* @route '/ads/order'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AdOrderController::store
* @see app/Http/Controllers/AdOrderController.php:33
* @route '/ads/order'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\AdOrderController::payment
* @see app/Http/Controllers/AdOrderController.php:82
* @route '/ads/payment/{order}'
*/
export const payment = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: payment.url(args, options),
    method: 'get',
})

payment.definition = {
    methods: ["get","head"],
    url: '/ads/payment/{order}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdOrderController::payment
* @see app/Http/Controllers/AdOrderController.php:82
* @route '/ads/payment/{order}'
*/
payment.url = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order: args }
    }

    if (Array.isArray(args)) {
        args = {
            order: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        order: args.order,
    }

    return payment.definition.url
            .replace('{order}', parsedArgs.order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdOrderController::payment
* @see app/Http/Controllers/AdOrderController.php:82
* @route '/ads/payment/{order}'
*/
payment.get = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: payment.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdOrderController::payment
* @see app/Http/Controllers/AdOrderController.php:82
* @route '/ads/payment/{order}'
*/
payment.head = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: payment.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\AdOrderController::payment
* @see app/Http/Controllers/AdOrderController.php:82
* @route '/ads/payment/{order}'
*/
const paymentForm = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: payment.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdOrderController::payment
* @see app/Http/Controllers/AdOrderController.php:82
* @route '/ads/payment/{order}'
*/
paymentForm.get = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: payment.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdOrderController::payment
* @see app/Http/Controllers/AdOrderController.php:82
* @route '/ads/payment/{order}'
*/
paymentForm.head = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: payment.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

payment.form = paymentForm

/**
* @see \App\Http\Controllers\AdOrderController::simulatePayment
* @see app/Http/Controllers/AdOrderController.php:95
* @route '/ads/payment/{order}/simulate'
*/
export const simulatePayment = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: simulatePayment.url(args, options),
    method: 'post',
})

simulatePayment.definition = {
    methods: ["post"],
    url: '/ads/payment/{order}/simulate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdOrderController::simulatePayment
* @see app/Http/Controllers/AdOrderController.php:95
* @route '/ads/payment/{order}/simulate'
*/
simulatePayment.url = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order: args }
    }

    if (Array.isArray(args)) {
        args = {
            order: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        order: args.order,
    }

    return simulatePayment.definition.url
            .replace('{order}', parsedArgs.order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdOrderController::simulatePayment
* @see app/Http/Controllers/AdOrderController.php:95
* @route '/ads/payment/{order}/simulate'
*/
simulatePayment.post = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: simulatePayment.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AdOrderController::simulatePayment
* @see app/Http/Controllers/AdOrderController.php:95
* @route '/ads/payment/{order}/simulate'
*/
const simulatePaymentForm = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: simulatePayment.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AdOrderController::simulatePayment
* @see app/Http/Controllers/AdOrderController.php:95
* @route '/ads/payment/{order}/simulate'
*/
simulatePaymentForm.post = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: simulatePayment.url(args, options),
    method: 'post',
})

simulatePayment.form = simulatePaymentForm

/**
* @see \App\Http\Controllers\AdOrderController::createBlade
* @see app/Http/Controllers/AdOrderController.php:118
* @route '/blade/ads/order'
*/
export const createBlade = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createBlade.url(options),
    method: 'get',
})

createBlade.definition = {
    methods: ["get","head"],
    url: '/blade/ads/order',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdOrderController::createBlade
* @see app/Http/Controllers/AdOrderController.php:118
* @route '/blade/ads/order'
*/
createBlade.url = (options?: RouteQueryOptions) => {
    return createBlade.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdOrderController::createBlade
* @see app/Http/Controllers/AdOrderController.php:118
* @route '/blade/ads/order'
*/
createBlade.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createBlade.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdOrderController::createBlade
* @see app/Http/Controllers/AdOrderController.php:118
* @route '/blade/ads/order'
*/
createBlade.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: createBlade.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\AdOrderController::createBlade
* @see app/Http/Controllers/AdOrderController.php:118
* @route '/blade/ads/order'
*/
const createBladeForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: createBlade.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdOrderController::createBlade
* @see app/Http/Controllers/AdOrderController.php:118
* @route '/blade/ads/order'
*/
createBladeForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: createBlade.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdOrderController::createBlade
* @see app/Http/Controllers/AdOrderController.php:118
* @route '/blade/ads/order'
*/
createBladeForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: createBlade.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

createBlade.form = createBladeForm

/**
* @see \App\Http\Controllers\AdOrderController::storeBlade
* @see app/Http/Controllers/AdOrderController.php:136
* @route '/blade/ads/order'
*/
export const storeBlade = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeBlade.url(options),
    method: 'post',
})

storeBlade.definition = {
    methods: ["post"],
    url: '/blade/ads/order',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdOrderController::storeBlade
* @see app/Http/Controllers/AdOrderController.php:136
* @route '/blade/ads/order'
*/
storeBlade.url = (options?: RouteQueryOptions) => {
    return storeBlade.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdOrderController::storeBlade
* @see app/Http/Controllers/AdOrderController.php:136
* @route '/blade/ads/order'
*/
storeBlade.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeBlade.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AdOrderController::storeBlade
* @see app/Http/Controllers/AdOrderController.php:136
* @route '/blade/ads/order'
*/
const storeBladeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeBlade.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AdOrderController::storeBlade
* @see app/Http/Controllers/AdOrderController.php:136
* @route '/blade/ads/order'
*/
storeBladeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeBlade.url(options),
    method: 'post',
})

storeBlade.form = storeBladeForm

/**
* @see \App\Http\Controllers\AdOrderController::paymentBlade
* @see app/Http/Controllers/AdOrderController.php:176
* @route '/blade/ads/payment/{order}'
*/
export const paymentBlade = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: paymentBlade.url(args, options),
    method: 'get',
})

paymentBlade.definition = {
    methods: ["get","head"],
    url: '/blade/ads/payment/{order}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdOrderController::paymentBlade
* @see app/Http/Controllers/AdOrderController.php:176
* @route '/blade/ads/payment/{order}'
*/
paymentBlade.url = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order: args }
    }

    if (Array.isArray(args)) {
        args = {
            order: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        order: args.order,
    }

    return paymentBlade.definition.url
            .replace('{order}', parsedArgs.order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdOrderController::paymentBlade
* @see app/Http/Controllers/AdOrderController.php:176
* @route '/blade/ads/payment/{order}'
*/
paymentBlade.get = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: paymentBlade.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdOrderController::paymentBlade
* @see app/Http/Controllers/AdOrderController.php:176
* @route '/blade/ads/payment/{order}'
*/
paymentBlade.head = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: paymentBlade.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\AdOrderController::paymentBlade
* @see app/Http/Controllers/AdOrderController.php:176
* @route '/blade/ads/payment/{order}'
*/
const paymentBladeForm = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: paymentBlade.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdOrderController::paymentBlade
* @see app/Http/Controllers/AdOrderController.php:176
* @route '/blade/ads/payment/{order}'
*/
paymentBladeForm.get = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: paymentBlade.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AdOrderController::paymentBlade
* @see app/Http/Controllers/AdOrderController.php:176
* @route '/blade/ads/payment/{order}'
*/
paymentBladeForm.head = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: paymentBlade.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

paymentBlade.form = paymentBladeForm

/**
* @see \App\Http\Controllers\AdOrderController::simulatePaymentBlade
* @see app/Http/Controllers/AdOrderController.php:189
* @route '/blade/ads/payment/{order}/simulate'
*/
export const simulatePaymentBlade = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: simulatePaymentBlade.url(args, options),
    method: 'post',
})

simulatePaymentBlade.definition = {
    methods: ["post"],
    url: '/blade/ads/payment/{order}/simulate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdOrderController::simulatePaymentBlade
* @see app/Http/Controllers/AdOrderController.php:189
* @route '/blade/ads/payment/{order}/simulate'
*/
simulatePaymentBlade.url = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order: args }
    }

    if (Array.isArray(args)) {
        args = {
            order: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        order: args.order,
    }

    return simulatePaymentBlade.definition.url
            .replace('{order}', parsedArgs.order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdOrderController::simulatePaymentBlade
* @see app/Http/Controllers/AdOrderController.php:189
* @route '/blade/ads/payment/{order}/simulate'
*/
simulatePaymentBlade.post = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: simulatePaymentBlade.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AdOrderController::simulatePaymentBlade
* @see app/Http/Controllers/AdOrderController.php:189
* @route '/blade/ads/payment/{order}/simulate'
*/
const simulatePaymentBladeForm = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: simulatePaymentBlade.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AdOrderController::simulatePaymentBlade
* @see app/Http/Controllers/AdOrderController.php:189
* @route '/blade/ads/payment/{order}/simulate'
*/
simulatePaymentBladeForm.post = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: simulatePaymentBlade.url(args, options),
    method: 'post',
})

simulatePaymentBlade.form = simulatePaymentBladeForm

const AdOrderController = { create, store, payment, simulatePayment, createBlade, storeBlade, paymentBlade, simulatePaymentBlade }

export default AdOrderController